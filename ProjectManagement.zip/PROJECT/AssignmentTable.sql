 --Assignments table
--CREATE TABLE Assignments (
   -- ResourceID INT,
    --TaskID INT,
    --Hours_Worked INT,
    --FOREIGN KEY (ResourceID) REFERENCES Resources(ResourceID),
    --FOREIGN KEY (TaskID) REFERENCES Task(TaskID)
--);

INSERT INTO Assignments (ResourceID, TaskID, Hours_Worked)
VALUES
    (10, 1, 20),
    (11, 1, 25),
    (12, 2, 35),
    (14, 3, 15);

Select* From Assignments;