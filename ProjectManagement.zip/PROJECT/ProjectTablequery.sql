--Create Database ProjectManagement;
Create table Project(
    ProjectID INT IDENTITY(201,1) PRIMARY KEY,
    ProjectName VARCHAR(70) NOT NULL,
    StartDate DATE,
    EndDate DATE,
    Description TEXT,
	Budget INT,
    CHECK(StartDate < EndDate) 
);
Insert into Project(ProjectName, StartDate, EndDate, Description, Budget)
values('E-Commerce Platform', CAST('2024-03-04'AS DATE),CAST('2024-12-04'AS DATE), 'Development of Online Store', 7000),
('CRM System Upgrade', CAST('2024-01-06'AS DATE), CAST('2024-06-06' AS DATE), 'Upgrade Existing CRM system', 40000),
('Website Development', CAST('2024-04-05' AS DATE), CAST('2024-08-02' AS DATE), 'Developing a shopping brand website', 10000),
('Cybersecurity Project', CAST('2024-02-07' AS DATE), CAST('2024-12-12' AS DATE), 'Improving system security', 50000),
('Data Analytics Platform',CAST('2024-04-05' AS DATE), CAST('2024-10-10' AS DATE), 'Development of analytics platform', 11000);
 
 Select* From Project;