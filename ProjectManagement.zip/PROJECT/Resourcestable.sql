-- Resources table
--CREATE TABLE Resources (
  --  ResourceID INT IDENTITY(1,1) PRIMARY KEY,
    --ResourceName VARCHAR(100) NOT NULL,
	--Gender Varchar,
    --Skill VARCHAR(55),
    --Availability VARCHAR 
--);
--ALTER TABLE ProjectManagement.dbo.Resources
--ALTER COLUMN Availability VARCHAR(10); 
--INSERT INTO Resources (ResourceName, Gender,Skill, Availability)
--VALUES
--('Alex Smith', 'M', 'Database Management', 'Full Time'),
--('Emma', 'F', 'Full Stack Developer', 'Full Time'),
--('Ali Asghar', 'M', 'Frontend Developer', 'Part Time'),
--('Sarah Saad', 'F', 'Database Management', 'Part Time'),
--('Zara Hasan', 'F', 'Network Administration', 'Full Time'),
--('Fahad', 'M', 'Full Stack Developer', 'Full Time'),
--('Ahmad Malik', 'Male', 'Backend Developer', 'Full Time');

Select* from Resources;
 

