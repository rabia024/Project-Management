--Create table Task(
  --  TASKID INT IDENTITY(1,1) PRIMARY KEY,
	--ProjectID INT,
    --TaskName VARCHAR(70) NOT NULL,
    --StartDate DATE,
    --EndDate DATE,
	--EstimatedHours INT,
	--FOREIGN KEY(ProjectID) REFERENCES Project(ProjectID),
    --CHECK (StartDate<EndDate) 
--);
Insert into Task(ProjectID, TaskName, StartDate, EndDate, EstimatedHours)
values(203,'Database Design', CAST('2024-06-04'AS DATE),CAST('2024-06-09'AS DATE),40),
(203,'UX Design', CAST('2024-06-04'AS DATE), CAST('2024-06-09' AS DATE), 40),
(204,'Frontend Development', CAST('2024-06-04' AS DATE), CAST('2024-06-09' AS DATE), 60),
(205,'Backend Development', CAST('2024-06-08' AS DATE), CAST('2024-06-16' AS DATE), 50),
(206,'Network Configuration',CAST('2024-06-07' AS DATE), CAST('2024-06-13' AS DATE), 20),
(206,'Software Testing',CAST('2024-06-07' AS DATE), CAST('2024-06-13' AS DATE),20),
(207,'Security Testing',CAST('2024-06-09' AS DATE), CAST('2024-06-11' AS DATE),35)
;

Select* from task;
